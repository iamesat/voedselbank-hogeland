$('#buttonstap2').click(function() {
	$('#stap2').removeClass('overlay');
});

$('#buttonstap3').click(function() {
	$('#stap3').removeClass('overlay');
});
